from django.apps import AppConfig


class DelivererConfig(AppConfig):
    name = 'deliverer'
