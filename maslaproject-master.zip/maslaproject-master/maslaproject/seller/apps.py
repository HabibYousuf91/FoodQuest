from django.apps import AppConfig


class SellerConfig(AppConfig):
    name = 'seller'
