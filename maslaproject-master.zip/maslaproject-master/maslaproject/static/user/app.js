function checked(){
   var icon1= document.getElementById('icon');
   icon1.style.color="darkorange";
}
function checked1(){
    var icon1= document.getElementById('icon1');
    icon1.style.color="darkorange";
 }
 function checked2(){
    var icon1= document.getElementById('icon2');
    icon1.style.color="darkorange";
 }
 function checked3(){
    var icon1= document.getElementById('icon3');
    icon1.style.color="darkorange";
 }
 function checked4(){
    var icon1= document.getElementById('icon4');
    icon1.style.color="darkorange";
 }